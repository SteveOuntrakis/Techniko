package com.team3.techniko.model.enums;

public enum Status {
    PENDING,IN_PROGRESS,COMPLETED,CANCELLED

}
