package com.team3.techniko.model.enums;

public enum RepairType {
    PAINTING,
    INSULATION,
    FRAMES,
    PLUMBING,
    ELECTRICAL_WORK
}
