package com.team3.techniko.Utils;

public class Finals {
  public static final String DELIMITER = "------------------------------------------------------------------------------------------------------";
}
