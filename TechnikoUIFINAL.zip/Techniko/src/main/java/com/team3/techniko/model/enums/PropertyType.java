package com.team3.techniko.model.enums;

public enum PropertyType {
    HOUSE,
    APARTMENT
}